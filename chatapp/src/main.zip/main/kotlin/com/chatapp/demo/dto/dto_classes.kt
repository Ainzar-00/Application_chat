
package com.chatapp.demo.dto

import com.chatapp.demo.model.ConversationParticipantId
import java.time.LocalDateTime

// User DTOs
data class CreateUserRequest(
    val username: String,
    val email: String,
    val phone: String,
    val password: String
)

data class UserResponse(
    val id: Int,
    val username: String,
    val email: String,
    val phone: String
)

// When a logged-in user updates their own profile we DON'T accept the id in the payload;
// the server will read the actor's id from the session.
data class UpdateUsername(
    val username: String
)

data class UpdateEmail(
    val email: String
)

data class UpdatePhone(
    val phone: String
)

data class UpdatePassword(
    val password: String,
    val confirmedPassword: String
)

// Conversation DTOs
// Creating a private conversation: client supplies the other user's id; creator is the session user
data class CreatePrivateConversationRequest(
    val otherUserId: Int,
    val customName: String? = null
)

// Creating a group: creator is the session user, so no creatorId in the DTO
data class CreateGroupConversationRequest(
    val name: String
)

data class ConversationResponse(
    val id: Int,
    val type: String,
    val name: String?,
    val createdAt: LocalDateTime?,
    val participantCount: Int
)

// Pagination-friendly request for listing user conversations (server uses session userId)
data class GetUserConversations(
    val page: Int = 0,
    val size: Int = 50
)

// Blocking options: target user is explicit, actor comes from session
data class BlockingOptions(
    val conversationId: Int,
    val targetUserId: Int
)

// Message operations: senderId and sentAt are NOT provided by client — server sets those from session & clock.
data class CreateMessage(
    val conversationId: Int,
    val content: String
)

data class MessageResponse(
    val id: Int?,
    val senderId: Int?,
    val content: String,
    val createdAt: LocalDateTime?
)


// Generic API wrapper
data class ApiResponse<T>(
    val success: Boolean,
    val message: String,
    val data: T? = null
)

// Group / participant related
data class UpdateGroupNameRequest(
    val conversationId: Int,
    val name: String
)

data class AddParticipantRequest(
    val userId: Int,
    val role: String = "Member"
)

data class ParticipantResponse(
    val id: ConversationParticipantId,
    val userId: Int?,
    val username: String?,
    val role: String?,
    val status: String,
    val joinedAt: LocalDateTime?
)

// Delete participant: actor is session user (must be authorized); targetUserId is the user to remove
data class DeleteParticipantConversation(
    val conversationId: Int,
    val targetUserId: Int
)

// Delete message: actor is taken from session
data class DeleteMessage(
    val messageId: Int
)

// Login DTOs: phone field is lowercase for conventional JSON mapping
data class LoginRequest(
    val email: String?,
    val phone: String?,
    val password: String
)

data class LoginResponse(
    val id: Int,
    val username: String,
    val email: String,
    val phone: String,
    val message: String
)
